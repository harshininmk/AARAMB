function validation() {
    if (document.Formfill.CollegeName.value === "") {
        document.getElementById("result").innerHTML = "Enter CollegeName*";
        return false;
    }
    if (document.Formfill.CollegeCode.value === "") {
        document.getElementById("result").innerHTML = "Enter CollegeCode*";
        return false;
    }
    if (document.Formfill.Email.value === "") {
        document.getElementById("result").innerHTML = "Enter your Email*";
        return false;
    }
    if (document.Formfill.Location.value === "") {
        document.getElementById("result").innerHTML = "Enter Location*";
        return false;
    }
    if (document.Formfill.CLocation.value === "") {
        document.getElementById("result").innerHTML = "Check Details";
        return false;
    }
    if (document.Formfill.Location.value.length < 6) {
        document.getElementById("result").innerHTML = "Confirm Details";
        return false;
    }

    // If all validations pass
    document.getElementById("result").innerHTML = ""; // Clear previous messages
    document.getElementById("popup").style.display = "block"; // Show success popup
    return true;
}