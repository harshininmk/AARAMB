<!DOCTYPE html>
<html lang="en">
<head>
    <title>Connect</title>
    <link rel="stylesheet" href="stylec.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Times New Roman', Times, serif;
        }
        body {
            background: url(assets/imgs/rbg.jpg) no-repeat;
            background-position: center;
            background-size: cover;
            min-height: 100vh;
            width: 100%;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .form-box {
            position: relative;
            width: 400px;
            height: 550px;
            border: transparent;
            border-radius: 20px;
            backdrop-filter: blur(15px);
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .form-box h2 {
            color: #879868;
            text-align: center;
            font-size: 32px;
        }
        .input-box {
            position: relative;
            margin: 30px 0;
            width: 310px;
            border-bottom: 2px solid white;
        }
        .input-box input {
            width: 100%;
            height: 45px;
            background: transparent;
            border: none;
            outline: none;
            padding: 0 20px 0 5px;
            color: rgb(0, 0, 0);
            font-size: 20px;
        }
        input::placeholder {
            color: rgb(3, 0, 91);
        }
        .btn {
            color: white;
            background: #879868;
            width: 100%;
            height: 50px;
            outline: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            box-shadow: 3px 0 10px rgba(0, 0, 0, .5);
        }
        .group {
            color: white;
            position: relative;
            top: 10px;
            text-decoration: none;
            font-weight: 500;
        }
        .group a:focus {
            text-decoration: underline;
        }
        .result {
            color: red;
            font-weight: 600;
            position: relative;
            top: 25px;
        }
        .popup {
            width: 300px;
            background-color: rgb(255, 255, 255);
            border-radius: 5px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) scale(0);
            transition: transform 0.4s, top 0.4s;
            visibility: hidden;
            text-align: center;
            padding: 20px;
            height: auto;
            color: black;
        }
        .popup ion-icon {
            color: #00ff00;
            font-size: 50px;
        }
        .popup button {
            width: 50%;
            background: rgba(2, 224, 80, 0.744);
            padding: 5px 0;
            margin-top: 20px;
            border: none;
            outline: none;
            font-size: 20px;
            color: rgb(1, 12, 68);
            border-radius: 5px;
            cursor: pointer;
            box-shadow: 0 0 2px rgba(0, 0, 0, .1);
        }
        .popup a {
            color: white;
            text-decoration: none;
            font-weight: 600;
            letter-spacing: 2px;
        }
        .open-slide {
            top: 50%;
            transform: translate(-50%, -50%) scale(1);
            visibility: visible;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-box">
            <form action="nss2.php" method="post">
                <h2>REGISTER</h2>
                <div class="input-box">
                    <input type="hidden" id="NSSname" name="NSSname" placeholder="nss2inar Name" required>
                </div>
                <div class="input-box">
                    <input type="text" id="Email" name="Email" placeholder="Your Email" required>
                </div>
                <div class="input-box">
                    <input type="text" id="Password" name="Password" placeholder="Password" required>
                </div>
                <div class="input-box">
                <div class="button">
                    <input type="submit" class="btn" value="Submit" name="submit">
                </div>
            </form>
        </div>
        <div id="popup" class="popup">
            <ion-icon name="checkmark-circle-outline"></ion-icon>
            <h2>Thank you!</h2>
            <p>Your registration is successful.</p>
            <a href="nss.html"><button>OK</button></a>
        </div>
    </div>
    <?php
    
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database credentials
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "aaramb";

// Function to sanitize user input
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Initialize error messages and success message variable
$successMessage = "";
$NSSnameErr = $EmailErr = $PasswordErr = "";
$isValid = true;

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Define variables and set to empty values
    $NSSname = $Email = $Password = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $NSSname = trim($_POST['NSSname']);
    $Email = trim($_POST['Email']);
    $Password = trim($_POST['Password']);
    $errors = [];

     // Validate NSSname
     if (empty($NSSname)) {
        $errors[] = "NSSname is required.";
    } elseif (!filter_var($NSSname, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid Event Name format.";
    }

    // Validate email
    if (empty($email)) {
        $errors[] = "Email is required.";
    } elseif (!filter_var($Email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    // Validate password
    if (empty($password)) {
        $errors[] = "Password is required.";
    } elseif (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters long.";
    }

    // Check if the email already exists
    if ($isValid) {
        // Establish connection to the database
        $conn = new mysqli($servername, $db_username, $db_password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Check if email already exists
        $stmt = $conn->prepare("SELECT COUNT(*) FROM nss2 WHERE Email = ? AND NSSname = ?");
        $stmt->bind_param("ss", $Email, $NSSname);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();
        $stmt->close();

        if ($count > 0) {
            $EmailErr = "You have Registered for this event";
            $isValid = false;
        echo "You have already Registered for this event";
        }
        // If email is unique, proceed to insert the new record
        if ($isValid) {
            // Prepare and bind the SQL statement
            $stmt = $conn->prepare("INSERT INTO nss2 (NSSname, Email, Password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $NSSname, $Email, $Password);

            // Execute the statement
            if ($stmt->execute()) {
                $successMessage = "Registration for event successful!";
                echo "<script>
                        document.getElementById('popup').classList.add('open-slide');
                        setTimeout(function() {
                            document.getElementById('popup').classList.remove('open-slide');
                        }, 5000);
                      </script>";
            } else {
                echo "Error: " . $stmt->error;
            }

            // Close the statement and connection
            $stmt->close();
        }

        $conn->close();
    }
}
}
?>

</body>
</html>