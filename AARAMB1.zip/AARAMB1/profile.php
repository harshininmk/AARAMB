<?php
session_start();  // Start the session

// Check if the user is logged in
if (!isset($_SESSION['Email'])) {
    header("Location: login.php");  // Redirect to login page if not logged in
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            display: flex;
            height: 100vh;
            justify-content: center;
            align-items: center;
            background-color: #e9f5db;
            background-size: cover;
            background-position: center;
            margin: 0;
        }
        
        header {
            position: absolute;
            top: 0;
            width: 100%;
            background-color: #879868;
            color: #052653;
            text-align: center;
            padding: 40px 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }
        
        .container {
            width: 685px;
            height: 450px;
            background: transparent;
            border: 2px solid rgba(255, 255, 255, .2);
            backdrop-filter: blur(20px);
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
            margin-top: 60px;
        }

        .form-title {
            font-size: 26px;
            font-weight: 600;
            text-align: center;
            color: black;
            border-bottom: solid 1px #ffffff;
            padding-bottom: 10px;
        }
        
        .about-section {
            padding: 2rem;
        }
        
        .about-content {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .about-content img {
            width: 350px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        
        .text-content {
            color: #4a372b;
            text-align: left;
            width: 100%;
        }
        
        .text-content p {
            display: relative;
            text-align: center;
            margin: 0.5rem 0;
        }
    </style>
</head>
<body>
<header>
    <h2>USER PROFILE</h2>
</header>
<main>
    <br>
    <br>
    <br>
    <br>
    <section class="about-section">
        <div class="container">
            <div class="about-content">
                <img src="assets/imgs/logo.jpg" alt="Profile Image">
                <br>
                <div class="text-content">
                    <p><strong>COLLEGE NAME:</strong> <?php echo htmlspecialchars($_SESSION['CollegeName']); ?></p>
                    <p><strong>COLLEGE CODE:</strong> <?php echo htmlspecialchars($_SESSION['CollegeCode']); ?></p>
                    <p><strong>PASSWORD:</strong> <?php echo htmlspecialchars($_SESSION['Password']); ?></p>
                    <p><strong>EMAIL:</strong> <?php echo htmlspecialchars($_SESSION['Email']); ?></p>
                    <p><strong>LOCATION:</strong> <?php echo htmlspecialchars($_SESSION['Location']); ?></p>
                </div>
            </div>
        </div>
    </section>
</main>
</body>
</html>
